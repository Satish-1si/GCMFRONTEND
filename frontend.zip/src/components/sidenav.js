// src/components/SideNav.js
import React, { useState } from 'react';
import "../sass/sidenav.scss";
import user from "../sass/icons/user.svg";
import device from "../sass/icons/device.svg";
import Dot from "../sass/icons/dot.svg";
import settings from "../sass/icons/settings.svg";
import password from "../sass/icons/password.svg";
import NavIcon from "../sass/icons/navIcon.svg";
import imageBg from "../sass/images/bg_1.jpg"
import navIcon from "../sass/icons/navIcon.svg";

import { Sidebar, Menu, MenuItem, SubMenu, ProSidebarProvider } from 'react-pro-sidebar';

const SideNav = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  return (
   
    <div className="Dashboard" >
      <div className="customize"   >
      {<h2 className="p-0" style={{overflow:"hidden",color:"white"}}>
                 <img src={navIcon} alt="Dot Icon" className='p-3'
                 onClick={()=>{ setIsCollapsed((b)=>!b)}}
                />
                  {(isCollapsed===false)?"GCM Dailer":""}
                  </h2>}
        <ProSidebarProvider>
       
          <Sidebar 
          collapsed={isCollapsed} 
          className="app"
          backgroundColor="rgb(34, 45, 50)"
          style={{color:"#FDF6F6",height:"88vh"}}
          // image={imageBg}
        
          >
              
            <Menu>
             
           
              <SubMenu title="User Management" label="User Management" icon={<img src={user} alt="User Icon" />}>
                <MenuItem className='text-primary'><img src={Dot} alt="Dot Icon" /> Add New Users </MenuItem>
                <MenuItem className='text-primary'><img src={Dot} alt="Dot Icon" /> View Users </MenuItem>
              </SubMenu>
              <SubMenu title="Device Details" label="Device Details" icon={<img src={device} alt="Device Icon" />}>
                <MenuItem className='text-primary'><img src={Dot} alt="Dot Icon" /> View All Details </MenuItem>
                <MenuItem className='text-primary'><img src={Dot} alt="Dot Icon" /> View Android Users </MenuItem>
                <MenuItem className='text-primary'><img src={Dot} alt="Dot Icon" /> View iPhone Users </MenuItem>
              </SubMenu>
              <SubMenu title="Tenant Management" label="Tenant Management" icon={<img src={password} alt="Password Icon" />}>
                <MenuItem className='text-primary'><img src={Dot} alt="Dot Icon" /> Add Tenant </MenuItem>
                <MenuItem className='text-primary'><img src={Dot} alt="Dot Icon" /> View Tenant </MenuItem>
              </SubMenu>
              <SubMenu title="Settings" label="Settings" icon={<img src={settings} alt="Settings Icon" />}>
                <MenuItem className='text-primary'><img src={Dot} alt="Dot Icon" /> Configure Session Time</MenuItem>
                <MenuItem className='text-primary'><img src={Dot} alt="Dot Icon" /> Change Password </MenuItem>
              </SubMenu>
            </Menu>
          </Sidebar>

        </ProSidebarProvider>
        
      </div>
      <div className='section' style={{width:"100vw",height:"100vh",background:"white"}}>
         <h2 className='hf text-white p-3'>Super Admin panel</h2>
         <div className='bg-white'>

         </div>
         <p className='hf text-dark p-3 m-0' style={{background:"#f8f9fa",color:"black",textAlign:"start"}}>Copyright © 2017 GCM Dialer. All rights reserved.</p>
      </div>
    </div>
  );
}

export default SideNav;
