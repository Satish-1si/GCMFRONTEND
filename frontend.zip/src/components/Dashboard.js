import React from 'react'
import SideNav from './sidenav'
const Dashboard = () => {
  return (
    <div >
       <SideNav/>
    </div>
  )
}

export default Dashboard