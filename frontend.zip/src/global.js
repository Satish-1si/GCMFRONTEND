import React, { useCallback, useEffect, useState } from "react";
import Dashboard from "./components/Dashboard";
import "./global.css";
import "bootstrap/dist/css/bootstrap.min.css"; // Import Bootstrap CSS
import "./global.scss";
import BootstrapTable from "react-bootstrap-table-next";
import 'react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css';
import paginationFactory from 'react-bootstrap-table2-paginator';
import overlayFactory from 'react-bootstrap-table2-overlay';

/*
1.{Definedcolumn(R):addrow(R)} 
2.paginationFactory()==> edit the pageCount

*/

const MyTableComponent = () => {
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState([]);

  useEffect(() => {
    // Simulate data fetching
    setLoading(true);
    fetchData().then((data) => {
      setData(data);
      setLoading(false);
    });
  }, []);

  const columns = [
    { dataField: 'id', text: 'ID' },
    { dataField: 'name', text: 'Name' },
    { dataField: 'value', text: 'Value' },
  ];

  const fetchData = () => {
    // Simulated data fetching function
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve([
          { id: 1, name: 'Item 1', value: 100 },
          { id: 2, name: 'Item 2', value: 200 },
          { id: 3, name: 'Item 3', value: 300 },
        ]);
      }, 10000); // Simulated delay of 2 seconds
    });
  };

  // Define custom overlay
  const customOverlay = overlayFactory({
    spinner: true,
    background: 'rgba(192,192,192,0.3)',
    loader: <div className="custom-loading text-primary fw-bold">Loading...</div>,
    overlay: <div className="custom-overlay">Custom Overlay</div>,
  });

  return (
    <div>
      <BootstrapTable
        keyField="id"
        data={data}
        columns={columns}
        pagination={paginationFactory()}
        overlay={ overlayFactory({ spinner: true, background: 'rgba(192,192,192,0.3)' }) }
        remote // Ensure remote is enabled
      />
    </div>
  );
};
const Global = () => {
  const[C,setC]=useState(true)
  let columns = [
    { dataField: 'id', text: 'Id' },
    { dataField: 'name', text: 'Name' },
    { dataField: 'animal', text: 'Animal' },
  ]
  let data = [
    { id: 1, name: 'George', animal: 'Monkey' },
    { id: 1, name: 'Jeffrey', animal: 'Giraffe' },
    { id: 3, name: 'Alice', animal: 'Giraffe' },
    { id: 4, name: 'Alice', animal: <button onClick={()=>setC((obj)=>!obj)}>click-{C}</button> }
  ]
	return (
		<MyTableComponent/>
	);
};

export default Global;
